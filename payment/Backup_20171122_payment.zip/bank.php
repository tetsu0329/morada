<?php
session_start();
ob_start();
include_once("config.php");

// NOTE: Please set to $_SESSION["paymentAck"] = "BANK_DEPOSIT" before executing/calling payment/bank.php

if(!isset($_SESSION["product"]) || isset($_SESSION["payment"]) || !isset($_SESSION["paymentAck"]) || !isset($_SESSION["CustomerID"]) )
{
    header('Location:../');
    exit;
}

if($_SESSION["paymentAck"] == "BANK_DEPOSIT")
{
    if(isset($_SESSION["paypal_products"])){
        unset($_SESSION["paypal_products"]);;
    }

    $userId = $_SESSION["CustomerID"];
    $GrandTotal = 0.00;
    $ItemTotalPrice = 0.00;
    $ShippingFeeAmount = 0.00;
    $procc = $_GET['process'];
    // Create New Transaction Record
    $insert_row = $mysqli->query("INSERT INTO transactiontable
                (`userID`, `transactionStatus`, `paymentMethod`, `paypalTransactionID`, `totalAmount`, `itemAmount`, `shippingFeeAmount`, `note`)
                VALUES
                ('$userId','_INIT','BANK_DEPOSIT','', $GrandTotal, $ItemTotalPrice, $ShippingFeeAmount, '$procc')
              ");

    if($insert_row){
        $transactionID = $mysqli->insert_id;
        $getuseremail = $mysqli->query("SELECT * FROM usertable WHERE userID = $userId");
        $getuser = mysqli_fetch_assoc($getuseremail);
        $emailll = $getuser['userEmail'];
        $userrr = $getuser['userFname'];
        $userrr2 = $getuser['userFname']." ".$getuser['userLname'];
        $userAdd = $getuser['userAddress'];
        
        
        

    }else{
        die('Error : ('. $mysqli->errno .') '. $mysqli->error);
    }

    // Add Product ordered
    $ItemTotalPrice = 0;
    $ItemTotalQty = 0;
    $maills = " ";
    foreach ($_SESSION["product"] as $cart_item)
    {
        $orderedProductId = $cart_item[1];  //$cart_item[1] = productId (PK)
        $getuseremail2 = $mysqli->query("SELECT * FROM producttable WHERE productID= $orderedProductId");
        $getuser2 = mysqli_fetch_assoc($getuseremail2);
        $proddd = $getuser2['productName'];
        $piccc =  $getuser2['frontpic'];
        $orderedProductPrice = $cart_item[3] * 1.00;    //$cart_item[3] = price
        $orderedProductQty = $cart_item[4];             //$cart_item[4] = qty
        $orderedProductSize = $cart_item[5];            //$cart_item[5] = size (string)

        $insert_row = $mysqli->query("INSERT INTO itemtransactiontable
                  (`transactionID`, `productID`, `qty`, `price`, `size`, `note`) VALUES
                  ('$transactionID','$orderedProductId','$orderedProductQty','$orderedProductPrice','$orderedProductSize','')
              ");

        if(!$insert_row){
            die('Error : ('. $mysqli->errno .') '. $mysqli->error);
        }
        $maill = "<li style='border-bottom:1px solid black;list-style: none;width:80%;float: left;margin-left: 5%;margin-right:-40px;'>
				<div style='float: left;padding: 5px;text-align: center;width:30%;display: inline-block;'>
					<h3 style='font-family:century gothic;text-align:center;font-weight: normal;'>$proddd</h3>
					<img src='http://themeconcept.x10host.com/admin/$piccc' width='100' height='200'>
				</div>
				<div style='float: left;padding: 5px;text-align: center;width:30%;display: inline-block;'>
					<h3 style='font-family:century gothic;text-align:center;font-weight: normal;margin-top: 70%;'>QUANTITY&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$orderedProductQty</h3>
					<h3 style='font-family:century gothic;text-align:center;font-weight: normal;'>SIZE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$orderedProductSize</h3>
				</div>
				<br>
				<div style='float: left;padding: 5px;text-align: center;width:20%;display: inline-block;'>
				<br>
					<h3 style='font-family:century gothic;text-align:center;font-weight: normal;margin-top: 100%;'>PHP&nbsp;$orderedProductPrice .00</h3>
				</div>
			</li>";
        $maills = $maills." ".$maill;

        // item price X quantity
        $subtotal = $orderedProductPrice*$orderedProductQty;
        $ItemTotalQty = $ItemTotalQty + $orderedProductQty;

        //total price
        $ItemTotalPrice = $ItemTotalPrice + $subtotal;
    }
   if($_GET['process']=="Delivery"){
    // GrandTotal = Item Total Price + Shipping Cost
    $ShippingFeeAmount = $shippingCost["first3"];
    if($ItemTotalQty > 3) {
        $ShippingFeeAmount += $shippingCost["next5"];
        if ($ItemTotalQty > 8) {
            $ShippingFeeAmount += ceil(($ItemTotalQty - 8) / 3) * $shippingCost["additional"];
        }
    }
    }
    if($_GET['process']=="Pickup"){
    $ShippingFeeAmount = 0;
    }

    $GrandTotal = ($ItemTotalPrice + $ShippingFeeAmount);
    $to = $emailll;
			$subject = "Bank Deposit Waiting";
			$Message = "
<center>
<div style='width: 700px;padding:0;margin:0;'>
	<img src='http://themeconcept.x10host.com/img/tc.png' width='100%' style='margin-right:-40px; margin-left:50px;'>
	<h1 style='font-family:century gothic;text-align:center;font-weight: normal;'>Thank you for shopping with us!</h1>
	<div style='height:100%;padding-bottom: 10%;position: relative;'>
		<p style='font-family:century gothic;text-align:center;font-weight: normal;margin-right:-40px;'>
		Hi $userrr! , We have received your order and are waiting for <br> your bank deposit slip email. We will notify you once we've received it <br>and have your items shipped right away.
		</p>
		<br>
		<p style='font-family:century gothic;text-align:center;font-weight:bold;font-size:15px;'>Order Number:	$transactionID</p>
		<hr width='80%' style='background: black;'>
		
		<ul>
		<center>
			$maill
			</center>
			<li  style='border-bottom:1px solid black;list-style: none;width:104%;float: left;background: #313232;margin-left:-60px;margin-top:10px;text-align: center;color: white;padding:5px 10px 5px 10px;'>
				 	<h4 style='font-family:century gothic;text-align:center;font-weight:normal;color: white;'>SUBTOTAL: PHP $ItemTotalPrice .00</h4>
				 	<h4 style='font-family:century gothic;text-align:center;font-weight:normal;color: white;'>SHIPPING: PHP $ShippingFeeAmount .00</h4>
				 	<h4  style='font-family:century gothic;text-align:center;font-weight: normal;color:gray;'>Shipping takes up to 2-4<br>working days upon purchase.</h4>
			</li>
			<li  style='border-bottom:1px solid black;list-style: none;width:104%;float: left;background:transparent;margin-left: -60px;text-align: center;color: white;padding:5px 10px 5px 10px;'>
				<h4 style='font-family:century gothic;text-align:left;font-weight:bold;color:#313232;'>DELIVER TO:&nbsp;<span style='font-weight: normal;'>$userrr2</span></h4>
				<h4 style='font-family:century gothic;text-align:left;font-weight:bold;color:#313232;'>DELIVERY ADDRESS:&nbsp;<span style='font-weight: normal;'>$userAdd</span></h4>
				<h4 style='font-family:century gothic;text-align:left;font-weight:bold;color:#313232;'>PAYMENT METHOD:&nbsp;<span style='font-weight: normal;'>Bank Deposit</span></h4>
				<h4 style='font-family:century gothic;text-align:left;font-weight:bold;color:#313232;'>BILLING ADDRESS:&nbsp;<span style='font-weight: normal;'>$userAdd</span></h4>
				<br>
				<center>
					<h2 style='font-family:century gothic;text-align:center;font-weight:normal;color:#313232;'>Reminder</h2>
				</center>
				<br><br>
				
				<img src='http://themeconcept.x10host.com/img/checkk.png' alt='Check' width='100%'>
				
			</li>
		<li  style='font-family:century gothic;border-bottom:1px solid black;list-style: none;background: #313232;width:104%;float: left;margin-left: -60px;text-align: center;color: white;padding:5px 10px 5px 10px;font-weight: normal;font-size: 12px;'>
			<p>GET THE LATEST UPDATES ON SOCIAL MEDIA!</p>

			<a href='https://www.facebook.com' ><img border='0' src='http://themeconcept.x10host.com/img/facebooklogo.png' width='30' height='30'></a>

			<a href='https://www.instagram.com'><img border='0' src='http://themeconcept.x10host.com/img/instagramlogo.png' width='30' height='30'></a>


		
			<br>
			<br>

			<a href='/tc/privacy.php' style='font-size:12px;text-decoration:none; color:white; cursor:pointer;' >PRIVACY</a> | <a href='/tc/tnc.php' style='text-decoration:none; color:white; cursor:pointer;'>TERMS AND CONDITION</a>
	<br><br>
			<p>&copy; THEMECONCEPTS- 2017 ALL RIGHTS RESERVED.</p>
	</li>
		</ul>
	</div>	
</div>
</center>
			";
			
		$headers  = 'MIME-Version: 1.0' . "\r\n";
        	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        	$headers .= 'From: -----------.com';
		
		mail($to, $subject, $Message, $headers);

    // Update total price
    if($mysqli->query("UPDATE transactiontable SET `transactionStatus`='PENDING', `totalAmount` = '$GrandTotal', 
                `itemAmount` = '$ItemTotalPrice', `shippingFeeAmount` = '$ShippingFeeAmount'
                WHERE `userID` = '$userId' AND `transactionID` = '$transactionID'")) {
    } else {
        die('Error : ('. $mysqli->errno .') '. $mysqli->error);
    }

    // Acknowledge Transaction Compelete
    unset($_SESSION["paymentAck"]);
    unset($_SESSION["product"]);
    
    //echo "<script>alert('Transaction Succesful Check your Email'); windows.location.replace('ordertrack.php');</script>";

    echo '<h2>Transaction Successful. </h2>';
    echo '<br/> Transaction: Bank Deposit <br/>';
    echo 'Please deposit the amount within 48 hours. Afterwards, please send a copy of the validated bank deposit slip. Thank you. <br/><br/>';
    echo 'Transaction Id: '.$transactionID.'<br/>';
    echo 'Total Transaction Amount: PHP '.$GrandTotal.'<br/>';
    echo '========================= <br/>';
    echo 'Total Amount: PHP '.$ItemTotalPrice.'<br/>';
    echo 'Shipping Fee: PHP '.$ShippingFeeAmount.'<br/>';
    echo '<br/>';

    //TODO: DEBUG
    //var_dump($_SESSION);

} else {
    header('Location:../securecheckout');
    exit;
}

?>