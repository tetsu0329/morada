<?php
    session_start();
    ob_start();
    if(isset($_SESSION["product"]) && isset($_SESSION["payment"])){
        unset($_SESSION["payment"]);
    }

    if(isset($_SESSION["paypal_products"])){
        unset($_SESSION["paypal_products"]); //session no longer needed
    }

    if(isset($_SESSION["payment_error"])) {
        unset($_SESSION["payment_error"]);
    }

    echo '<br /><b>Transaction Cancelled</b><br />';
    echo '<br />Redirecting back... <br />';
    header('Refresh: 3;url=../securecheckout');
    exit;

?>